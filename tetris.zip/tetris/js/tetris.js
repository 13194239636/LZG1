
var tetris = {
	CELL_SIZE:26,//一个方块的大小
	RN:20,//行数
	CN:10,//列数
	OFFSET:15,//显示区域对于整个div的偏移量
	SCORE:[0,10,30,60,100,120,175,240],//下标为消的行数，得到对应的分数
	RANOBJ:[O,T,I,L,S,Z],//保存图形的名称
	GAMEOVER:0,
	RUNNING:1,
	PAUSE:2,
	state:1,
	random:0,//保存生成随机下一个图形的随机数
	div:null,//整个div界面
	shape:null,//当前的运动的图形
	interval:300,//定时时间
	timer:null,//定时器
	wall:null,//用于保存停下来的方块
	next:null,//下一个图形
	lines:0,//消去的行数
	score:0,//得到的分数
	reset:function(){
		this.shape = null;
		this.timer = null;
		this.next = null;
		this.lines = 0;
		this.score = 0;
		this.random = 0;
		for(var i=0;i<this.RN;i++){
			for(var j=0;j<this.CN;j++){
				this.wall[i][j]=null;
			}
		}
	},
	start:function(){//开始函数
		var self = this;
		self.div = document.querySelector("div");
		self.wall = [];
		for(var i=0;i<self.RN;i++){//初始化wall数组
			self.wall.push(new Array(self.CN));
		}
		self.state = self.RUNNING;
		self.score=0;
		self.lines=0;
		self.shape = new this.RANOBJ[4]();//创建当前图形
		self.random = Math.floor(Math.random()*this.RANOBJ.length);
		self.timer = setInterval(function(){//设置定时器
			self.moveDown();
			if(self.end()){//判断是否应该结束
				clearInterval(self.timer);
				alert("Game Over\n\[S\]重新开始");
				self.reset();
				try{
					self.paint();
				}catch(error){

				}
			}
		},self.interval);
		document.onkeydown = function(ev){//添加事件监听
			var ev = ev||window.event;
			switch(ev.keyCode){//键盘事件
				case 37:self.moveLeft();break;//左箭头事件左移
				case 39:self.moveRight();break;//右箭头右移
				case 40:self.moveDown();break;//下箭头快速下落
				case 38:self.rotateR();break;//上箭头顺时针翻转
				case 90:self.rotateL();break;//z字符逆时针翻转
				//Q 退出
				case 81:clearInterval(self.timer);
						self.state = self.GAMEOVER;
						self.timer=null;
						self.reset();
						try{
							self.paint();
						}catch(error){
						}
						
						alert("Game Over\n\[S\]重新开始");
						break;
				//p 暂停
				case 80:if(self.state=self.RUNNING){
							clearInterval(self.timer);
							self.state = self.PAUSE;
							self.timer= null;
							self.paint();

						}
						break;

				//g 继续
				case 71:if(self.state = self.PAUSE){
							self.timer = setInterval(function(){
								self.moveDown();
								self.state = self.RUNNING;
							},self.interval);
						}
						break;
				//s 重新开始
				case 83:
						clearInterval(self.timer);
						self.start();
						self.paint();
						break;
			}
		};
	},
	paint:function(){
		this.div.innerHTML = this.div.innerHTML.replace(/<img.*?>/g," ");//用正则表达式替换界面中所有的img标签，也就是删除上一个图形
		this.next = new this.RANOBJ[this.random]();//new出下一个图形
		this.paintShape();//重绘一个当前图形
		this.paintWall();//绘制停下来的图形
		this.paintNext();//绘制next里的图形
	},
	moveDown:function(){//下落函数
		if(this.canDown()){
			this.shape.moveDown();//调用原型中的moveDown方法
		}else{
			for(var i=0;i<this.shape.cells.length;i++){//当停止下落时添加当前图形到wall中
				var cell = this.shape.cells[i];
				this.wall[cell.r][cell.c] = cell;
			}

			this.lines = this.deleteRows();//调用deleteRows方法并且放回删除的行数
			this.paintScore(this.lines);//绘制分数
			this.paintLines(this.lines);//绘制消了几行
			this.shape = this.next;//替换当前图形
			this.random = Math.floor(Math.random()*this.RANOBJ.length);//产生下一个图形的下标
		}
		this.paint();

	},
	canDown:function(){//判断是否能下落
		//遍历cells数组，看是否有cell的r为RN-1，或者是否有cell的下一行有图形
		for(var i=0;i<this.shape.cells.length;i++){
			var cell = this.shape.cells[i];
			if(cell.r==this.RN-1||this.wall[cell.r+1][cell.c]){
				return false;
			}
		}
		return true;
	},
	moveLeft:function(){
		if(this.canLeft()){
			this.shape.moveLeft();//调用原型中的moveDown方法
		}
		
	},
	canLeft:function(){//判断能否左移
		//遍历cells数组，看是否有cell的c为0，或者是否有cell的上一列有图形
		for(var i=0;i<this.shape.cells.length;i++){
			var cell = this.shape.cells[i];
			if(cell.c==0||this.wall[cell.r][cell.c-1]){
				return false;
			}
		}
		return true;
	},
	moveRight:function(){
		if(this.canRight()){
			this.shape.moveRight();//调用原型中的moveDown方法
		}
	},
	canRight:function(){//判断能否右移
		//遍历cells数组，看是否有cell的c为CN-1，或者是否有cell的下一列有图形
		for(var i=0;i<this.shape.cells.length;i++){
			var cell = this.shape.cells[i];
			if(cell.c==this.CN-1||this.wall[cell.r][cell.c+1]){
				return false;
			}
		}
		return true;
	},
	rotateR:function(){
		//如果能旋转，符合旋转条件的话，就旋转，否则调用相反的方法，转回来
		this.shape.rotateR();
		if(!this.canRotate()){
			this.shape.rotateL();
		}
	},
	rotateL:function(){
		//如果能旋转，符合旋转条件的话，就旋转，否则调用相反的方法，转回来
		this.shape.rotateL();
		if(!this.canRotate()){
			this.shape.rotateR();
		}
	},
	canRotate:function(){//判断能否旋转
		//遍历数组cells，如果有cellc小于0或者c大于CN-1，或者r小于0或者r大于RN-1，或者调整之后的位置下已经有wall了，就不能旋转
		for(var i=0;i<this.shape.cells.length;i++){
			var cell = this.shape.cells[i];
			if(cell.c<0||cell.c>this.CN-1||cell.r<0||cell.r>this.RN-1||this.wall[cell.r][cell.c]!=null){
				return false;
			}
		}
		return true;
	},
	paintScore:function(lines){//绘制分数
		var oP = document.querySelector("#score p");
		oP.innerHTML=parseInt(oP.innerHTML)+this.SCORE[lines];
	},
	paintLines:function(lines){//绘制行数
		var oP = document.querySelector("#lines p");
		oP.innerHTML=parseInt(oP.innerHTML)+lines;
	},
	paintNext:function(){//绘制下一个图形
		var frag = document.createDocumentFragment();
		for(var i=0;i<this.next.cells.length;i++){
			var cell = this.next.cells[i];
			var img = new Image();
			img.src = cell.img;
			img.setAttribute("class","position");
			img.style.top = cell.r*this.CELL_SIZE+this.OFFSET+38+"px";
			img.style.left = cell.c*this.CELL_SIZE+this.OFFSET+264+"px";
			frag.appendChild(img);
		}
		this.div.appendChild(frag);
	},
	deleteRows:function(){//判断能否删除行并且返回删除掉的行数
		//保存删除的行数
		var lines=0;
		//遍历cells中的所有行
		for(var i=this.RN-1;i>=0;i--){
			//如果这一行中满了，就delete当前行
			if(this.isFullRow(i)){
				this.deleteRow(i);
				//i++是因为delete一行之后，上面的行就下来了，还需要再次检测当前行。抵消i--
				i++;
				//lines++
				lines++;
			}
		};
		//返回delete掉的行数
		return lines;
	},
	deleteRow:function(r){//调整删除和删除之后的方块
		//遍历r行以上的所有行
			for(var i=r;i>=0;i--){
				//让r-1行的所有cell都变为r行的
				this.wall[i] = this.wall[i-1];
				//r-1行的cell都为空
				this.wall[i-1]=[];
				//遍历r行设置r行的cell对象里的r都加一，用于重绘。
				for(var j=0;j<this.CN;j++){
					if(this.wall[i][j]){
						this.wall[i][j].r++;
					}
				}
				//上一行必为空，所以只能检测上第二行，检测上第二行的cell是不是都为空，都为空代表可以退出了
				if(this.canBreak(i-2)){
					break;
				}
			}	
	},
	isFullRow:function(r){//判断wall中的某一行是否为满
		//遍历这一行的所有cell
		for(var i=0;i<this.CN;i++){
			//有不为null的就放回false
			if(this.wall[r][i]==null){
				return false;
			}
		}
		//否则返回true
		return true;
	},
	canBreak:function(r){//判断是否可以结束遍历
		for(var i=0;i<this.CN;i++){
			if(this.wall[r][i]!=null){
				return false;
			}
		}
		return true;
	},
	paintWall:function(){//绘制停止的方块
 		//创建一个文档片段
 		var frag = document.createDocumentFragment();
		//遍历wall数组，如果有值，就进行paint。
		for (var i=0;i<this.wall.length;i++) {
		 	for(var j=0;j<this.wall[i].length;j++){
		 		var cell = this.wall[i][j];
		 		if(cell){
		 			//创建一个img对象来保存当前的wall对象
		 			var img = new Image();
		 			//img对象的src等于wall当前这个对象的img
		 			img.src = cell.img;
		 			//设置img的top和left
		 			img.setAttribute("class","position");
		 			img.style.top = cell.r*this.CELL_SIZE+this.OFFSET+"px";
		 			img.style.left = cell.c*this.CELL_SIZE+this.OFFSET+"px";
		 			//追加到frag中
		 			frag.appendChild(img);
		 		}
		 	}
		}
		//将文档片段追加到div中
		this.div.appendChild(frag);
	},
	paintShape:function(){//绘制当前图形
		//创建一个文段片段用来追加图形
		var frag = document.createDocumentFragment();
		//遍历图形数组，创建一个img变量用来保存当前cell
		for(var i in this.shape.cells){
			var img = new Image();
			//将当前cell的img属性赋给img变量的src
			var cell = this.shape.cells[i]
			img.src = cell.img;
			//设置这个img的top和left

			img.setAttribute("class","position");
			img.style.top = cell.r*this.CELL_SIZE+this.OFFSET+"px";
			img.style.left = cell.c*this.CELL_SIZE+this.OFFSET+"px";
			//当前img追加到文档片段中去
			frag.appendChild(img);
		}
		this.div.appendChild(frag);
	},
	end:function(){//判断结束
		//遍历wall对象，判断是否有r等于0的
		for(var i=0;i<this.RN;i++){
			for(var j=0;j<this.CN;j++){
				if(this.wall[i][j]){//必须要先判断wall中是否有值，不然会报错
					if(this.wall[i][j].r==0){
						this.state = this.GAMEOVER;
						return true;
					}
				}
				
			}
		}
		return false;
	}

}
window.onload = function(){//运行
	tetris.start();
}